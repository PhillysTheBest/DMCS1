#!/bin/bash

csv_file=$1
txt_file=$2

# delete the header and sort the rest based on the first field
# write the sorted data to the text file
tail -n +2 "$csv_file" | awk -F ',' '{print $1}' | sort | uniq > "$txt_file"





