PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE facultycsv (
    faculty TEXT,
    building TEXT,
    room TEXT,
    capacity INTEGER
);
COMMIT;
