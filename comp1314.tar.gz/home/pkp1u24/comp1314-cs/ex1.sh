#!/bin/bash

xml_file="$1"
csv_file="$2"

# Extract the start and end tags
start_tag=$(sed -n '3p' "$xml_file")
tagname=$(echo "$start_tag" | sed -E 's/^<([^>]+)>$/\1/' | xargs)  # Extract and trim tag name
end_tag="</$tagname>"

# Extract headers and save to the CSV file
awk -v start_tag="$start_tag" -v end_tag="$end_tag" '
  BEGIN { block_started = 0 }

  $0 == start_tag { block_started = 1; next }   
  $0 == end_tag { exit }                      

  block_started {
    if (match($0, /<([^\/>]+)(\/?)>/, matches)) {
      tag = matches[1]
      if (!(tag in seen)) {
        seen[tag] = 1
        headers = headers (headers ? "," : "") tag
      }
    }
  }

  END { print headers }
' "$xml_file" > "$csv_file"


# Extract data from every line
grep -v '<?xml' "$xml_file" | \
awk '
  # Process <faculty> blocks
  /<faculty>/ && !/<\/faculty>/ {
    block_start=1
    block=""
    current_tag="faculty"
    next
  }
  /<\/faculty>/ && !/<faculty>/ && block_start && current_tag == "faculty" {
    block_end=1
  }

  # Process <student> blocks
  /<student>/ && !/<\/student>/ {
    block_start=1
    block=""
    current_tag="student"
    gsub(/<student> */, "") 
  }
  /<\/student>/ && block_start && current_tag == "student" {
    block_end=1
  }

  # Process completed blocks
  block_start && block_end {
    print block
    block=""
    block_start=block_end=0
    next
  }

  block_start && current_tag == "faculty" {
    line = gensub(/.*>([^<]*)<.*/, "\\1", "g")  # Extract content between tags
    block = block (block ? "," : "") line
  }

  block_start && current_tag == "student" {
    # Handle <address> tag - start
    if ($0 ~ /<address>/) {
      line = gensub(/<address>/, "\"", "g")  # Replace <address> with " for formatting purposes
      getline next_line  # Get the next line
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", next_line) 
      next_line = gensub(/<\/address>/, "\"", "g", next_line)  # Replace </address> with " for formatting purposes
      line = line " " next_line  # Concatenate the two lines
      gsub(/[[:space:]]+/, " ", line) 
      block = block (block ? "," : "") line  # Add the processed address to the block
    }
    # Treates null tags as empty fields
    else if ($0 ~ /\/>/) {
      block = block (block ? "," : "") ""
    }
    # Extract content between tags for every other line
    else {
      line = gensub(/.*>([^<]*)<.*/, "\\1", "g")
      gsub(/[[:space:]]+/, " ", line)  
      block = block (block ? "," : "") line  # Add the extracted data to the block
    }
  }
' | \
# Remove leading whitespace and comma before the first character
sed 's/^ *, *//' >> "$csv_file"  # Append the extracted data to the CSV file















